<html>
	<body>
		<form method="POST" action="aula3.php">
            <div>
                <h1>Hotwheels</h1>
                <label>Modelo:</label><br>
                <input type="text" name="modelo" required><br><br>
                <label>Cor:</label><br>
                <input type="text" name="cor" required><br><br>
                <label>Ano:</label><br>
                <input type="text" name="ano" required><br><br>
            </div>
            <div>
                <h1>Pessoa</h1>
                <label>Nome:</label><br>
                <input type="text" name="nome" required><br><br>
                <label>Idade:</label><br>
                <input type="text" name="idade" required><br><br>
                <label>Endereço:</label><br>
                <input type="text" name="endereco" required><br><br>
                <input type="submit" value="Enviar"><br>
            </div>
		</form>
	</body>
</html>